import type TokenProcessor from "../TokenProcessor";
import Transformer from "./Transformer";
export default class NumericSeparatorTransformer extends Transformer {
    readonly tokens: TokenProcessor;
    constructor(tokens: TokenProcessor);
    process(): boolean;
}
