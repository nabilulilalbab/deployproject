import type TokenProcessor from "../TokenProcessor";
/**
 * Starting at a potential `with` or (legacy) `assert` token, remove the import
 * attributes if they exist.
 */
export declare function removeMaybeImportAttributes(tokens: TokenProcessor): void;
