import { TransformOptions, TRANSFORM_RESULT } from "./types";
export default function transform(opts: TransformOptions): TRANSFORM_RESULT;
