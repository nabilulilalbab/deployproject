import type { ScalarTag } from '../types';
export declare const intOct: ScalarTag;
export declare const int: ScalarTag;
export declare const intHex: ScalarTag;
