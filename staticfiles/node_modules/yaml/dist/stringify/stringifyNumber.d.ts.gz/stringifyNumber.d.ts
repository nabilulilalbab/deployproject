import type { Scalar } from '../nodes/Scalar';
export declare function stringifyNumber({ format, minFractionDigits, tag, value }: Scalar): string;
