import type { Token } from '../parse/cst';
export declare function emptyScalarPosition(offset: number, before: Token[] | undefined, pos: number | null): number;
